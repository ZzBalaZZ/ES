\# Kuidas AI-NFT töötab

\<img src=\".gitbook/assets/file.excalidraw.svg\" alt=\"\"
class=\"gitbook-drawing\"\>

See diagramm näitab AI-NFT arhitektuuri ja funktsionaalsust.

AI-NFT jaoks vajalikud põhikomponendid on loetletud allpool.

\* Laiendatud NFT metaandmed, sealhulgas AI-agendi märgiseadete fail \*
Tüüpiline NFT leping \* Tööaeg usaldusväärses täitmiskeskkonnas (TEE)
koos installitud Elizaga

Sel viisil saavad AI-NFT-d olemasolevaid raamistikke ja infrastruktuuri
võimendada. Lisades AI-agendi märgifaili (JSON-vormingus)
NFT-metaandmetesse ja levitades selle plokiahelas, teisendatakse
AI-agent sujuvalt ahelasiseseks varaks.

Lihtne on parim.

AI-NFT metaandmete kohta lisateabe saamiseks vaadake allolevat lehte.

{% content-ref url=\"ai-nft-metadata.md\" %}
\[ai-nft-metadata.md\](ai-nft-metadata.md) {% endcontent-ref %}
